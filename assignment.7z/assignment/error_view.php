<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/styles.css" />
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        <?php include 'navbar-unauth.php';?>
        <div class="content-view">
            <div class="row">
                <div class="col-sm-offset-2 col-sm-8">
                    <div class="text-center">
                        <div class="alert alert-danger">
                            <h3>Something Went Wrong:</h3>
                            <h4><?php echo $_SESSION["error"] ?></h4>
                            <h5><a href="login_view.php">&lt;&lt; Go Back</a></h5>
                        </div>
                    </div>
                </div>            
            </div>
        </div>
        <?php include 'footer.php';?>
    </div>
</body>
</html>