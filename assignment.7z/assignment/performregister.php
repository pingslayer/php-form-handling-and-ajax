<?php
session_start();
include 'UserService.php';

$userService = new UserService();
$fname = $_POST["fname"];
$email = $_POST['email'];
$password = $_POST['pass'];
$address = $_POST['address'];
if(validateDetails($fname, $email, $password)) {
    if($userService->checkEmail($email)) {
        $userService->saveUser($fname, $email, $password, $address);
        $_SESSION['serverMsg'] = "You Have Registered Successfully!";
        header("Location:login_view.php");
    } else { 
        $_SESSION['serverMsg'] = "E-Mail ID Is Already Taken!";
        header("Location:register_view.php");
    }
} else {
    $_SESSION['serverMsg'] = "One Or More Fields Are Blank!";
    header("Location:register_view.php");
}

/**
 * Details Validation
 */
function validateDetails($fname, $email, $password) {
    if($fname == "" || $email == "" || $password == "") {
        return false;
    }
    return true;
}

?>