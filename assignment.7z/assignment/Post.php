<?php
class Post {

    public $id;
    public $name;
    public $message;
    public $user;

    /**
     * Getters
     */
    public function getId() {
        return $this->id;
    }

    public function getName() {
        return $this->name;
    }

    public function getMessage() {
        return $this->message;
    }

    public function getUser() {
        return $this->user;
    }


    /**
     * Setters
     */
    public function setId($id) {
        $this->id = $id;
    }

    public function setName($name) {
        $this->name = $name;
    }

    public function setMessage($message) {
        $this->message = $message;
    }

    public function setUser($user) {
        $this->user = $user;
    }
}
?>