<?php
session_start();
if(!isset($_SESSION["email"])) {
    header("Location:login_view.php");
} else {
    header("Location:home_view.php");
}
?>