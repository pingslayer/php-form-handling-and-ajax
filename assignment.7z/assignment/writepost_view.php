<?php
session_start();
if(!isset($_SESSION["email"])) {
    header("Location:login_view.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/styles.css" />
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        <?php include 'navbar.php';?>
        <div class="content-view">
            <h3 class="text-center">Write A Post</h3>
            <hr>
            <div class="server-message" id="server-message">
                <?php
                if(isset($_SESSION["serverMsg"])) {
                    echo "<p class='text-center'>" . $_SESSION["serverMsg"] . "</p>";
                    unset($_SESSION['serverMsg']);
                }
                ?>
            </div>
            <div class="row">
                <div class="col-sm-offset-1 col-sm-10">
                    <form id="postUploadForm" action="performwritepost.php" method="post">
                        <div class="form-group form-group-mod">
                            <label class="control-label col-sm-2" for="pname">Post Name</label>
                            <div class="col-sm-10">
                                <input type="text" name="pname" id="pname" placeholder="Enter Post Name" class="form-control" onfocusout="validate_pname()">
                                <p id="pnameErrMsg"></p>
                            </div>
                        </div>
                        <div class="form-group form-group-mod">
                            <label class="control-label col-sm-2" for="pmessage">Post Message</label>
                            <div class="col-sm-10">
                                <textarea class="form-control" name="pmessage" id="pmessage" placeholder="Enter Post Message" onfocusout="validate_pmessage()"></textarea>
                                <p id="pmessageErrMsg"></p>
                            </div>
                        </div>
                        <div class="form-group form-group-mod text-center">
                            <button id="upload-btn" type="button" class="btn btn-primary form-btn" onclick="postUploadFormValidation()">Post</button>
                            <button id="reset-btn" type="reset" class="btn btn-warning form-btn" onclick="postUploadFormReset()">Reset</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include 'footer.php';?>
    </div>
</body>
<script>
    var pname = "";
    var pnameErrMsg = "";
    var pnameErrFlag = true;
    var pmessage = "";
    var pmessageErrMsg = "";
    var pmessageErrFlag = true;

    /**
    post name validation */
    function validate_pname() {
        pname = $("#pname").val();
        pnameErrFlag = false;
        pnameErrMsg = "";
        $("#pname").css({"border-color":"green"});
        if(pname == "" || pname == null || pname == undefined) {
            pnameErrFlag = true;
            pnameErrMsg = "Post Name Is Required !";
            $("#pname").css({"border-color":"red"});
        }
        $("#pnameErrMsg").text(pnameErrMsg);
    }

    /**
    post message validation */
    function validate_pmessage() {
        pmessage = $("#pmessage").val();
        pmessageErrFlag = false;
        pmessageErrMsg = "";
        $("#pmessage").css({"border-color":"green"});
        if(pmessage == "" || pmessage == null || pmessage == undefined) {
            pmessageErrFlag = true;
            pmessageErrMsg = "Password Is Required !";
            $("#pmessage").css({"border-color":"red"});
        }
        $("#pmessageErrMsg").text(pmessageErrMsg);
    }

    /**
    enter key submitting */
    $("#postUploadForm").keypress(function(e) {
        if(e.which == 13) {
            postUploadFormValidation();
        }
    });

    /**
    form validation and submitting */
    function postUploadFormValidation() {
        $("#server-message").text("");
        validate_pname();
        validate_pmessage();
        if(pnameErrFlag == false && pmessageErrMsg == false) {
            $("#pname").prop('readonly', true);
            $("#pmessage").prop('readonly', true);
            $("#login-btn").prop('disabled', true);
            $("#reset-btn").prop('disabled', true);
            $("#postUploadForm").submit();
        }
    }

    /**
    form reset */
    function postUploadFormReset() {
        pnameErrFlag = true;
        pmessageErrFlag = true;
        pnameErrMsg = "";
        pmessageErrMsg = "";
        $("#pnameErrMsg").text("");
        $("#pmessageErrMsg").text("");
        $("#pname").val("");
        $("#pmessage").val("");
        $("#pname").css({"border-color":"#ccc"});
        $("#pmessage").css({"border-color":"#ccc"});
        $("#server-message").text("");
    }
</script>
</html>