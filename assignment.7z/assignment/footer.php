<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <p class="footer-info footer-left">www.chandusoft.com - <?php echo date("Y"); ?>.</p>
            </div>
            <div class="col-sm-6">
                <p class="footer-info footer-right">PHP Assignment</p>
            </div>
        </div>
    </div>
</div>