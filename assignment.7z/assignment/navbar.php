<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="home_view.php">Assignment App</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="home_view.php">Home</a></li>
            <li><a href="writepost_view.php">Write Post</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a><span class="glyphicon glyphicon-user"></span> Welcome, <?php echo $_SESSION['email']; ?></a></li>
            <li><a href="performlogout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
        </ul>
    </div>
</nav>