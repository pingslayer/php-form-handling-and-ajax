<?php
class Mcrypt {

    private $key = "tB54GPfXgEL6UsC5lWirik65tXOwzmxG";

    public function encrypt($value) {
        $mcrypt = mcrypt_module_open('rijndael-256', '', 'cbc', '');
        $iv = mcrypt_create_iv(mcrypt_enc_get_iv_size($mcrypt), MCRYPT_DEV_RANDOM);
        mcrypt_generic_init($mcrypt, $this->key, $iv);
        $encryptedData = mcrypt_generic($mcrypt, $value);
        mcrypt_generic_deinit($mcrypt);
        mcrypt_module_close($mcrypt);
        return $encryptedData;
    }

    public function decrypt($value) {
        $mcrypt = mcrypt_module_open('rijndael-256', '', 'cbc', '');
        mcrypt_generic_init($mcrypt, $this->key, $iv);
        $decryptedData = mdecrypt_generic($mcrypt, $encryptedData);
        mcrypt_generic_deinit($mcrypt);
        mcrypt_module_close($mcrypt);
        return $decryptedData;
    }

}
?>