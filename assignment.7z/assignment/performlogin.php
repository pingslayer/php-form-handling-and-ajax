<?php
session_start();
include 'UserService.php';

$userService = new UserService();
$email = $_POST['email'];
$password = $_POST['pass'];
if(validateCredentials($email, $password)) {
    if($userId = $userService->checkUser($email, $password)) {
        $_SESSION['email'] = $email;
        $_SESSION['userId'] = $userId;
        header("Location:home_view.php");
    } else { 
        $_SESSION['serverMsg'] = "E-Mail ID And Password Didn't Match!";
        header("Location:login_view.php");
    }
} else {
    $_SESSION['serverMsg'] = "One Or More Fields Are Blank!";
    header("Location:login_view.php");
}

/**
 * Credential Validations
 */
function validateCredentials($email, $password) {
    if($email == "" || $password == "") {
        return false;
    }
    return true;
}

?>