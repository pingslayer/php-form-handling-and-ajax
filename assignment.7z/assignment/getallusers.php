<?php
include 'UserService.php';

$userService = new UserService();
header('Content-Type: application/json');
echo json_encode($userService->getAllUsers());
?>