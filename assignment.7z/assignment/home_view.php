<?php
session_start();
if(!isset($_SESSION["email"])) {
    header("Location:login_view.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="assets/css/styles.css" />
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        <?php include 'navbar.php';?>
        <div class="content-view">
            <h3 class="text-center">Posts</h3>
            <hr>
            <div class="server-msg">
                <?php
                if(isset($_SESSION["serverMsg"])) {
                    echo "<p class='text-center'>" . $_SESSION["serverMsg"] . "</p>";
                    unset($_SESSION['serverMsg']);
                }
                ?>
            </div>
            <div id="posts">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr class="info">
                            <th>Post Name</th>
                            <th>Post Message</th>
                        </tr>
                    </thead>
                    <tbody id="post-list">
                    </tbody>
                </table>
            </div>
        </div> 
        <?php include 'footer.php';?>
    </div>
</body>
<script>
    $.ajax({
        type: "GET",
        url: "getallposts.php",
        success: function(response) {
            var postListBuilder = "";
            if(response.length == 0) {
                $("#posts").html("<h4 class='text-center'>No Posts Available!</h4>");
                return;
            }
            for(var i=0; i<response.length; i++) {
                postListBuilder += "<tr>";
                postListBuilder += "<td>" + response[i].name + "</td>";
                postListBuilder += "<td>" + response[i].message + "</td>";
                postListBuilder += "</tr>";
            }
            $("#post-list").append(postListBuilder);
        }
    });
</script>
</html>