<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="login_view.php">Assignment App</a>
        </div>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="login_view.php">Login</a></li>
            <li><a href="register_view.php">Register</a></li>
        </ul>
    </div>
</nav>