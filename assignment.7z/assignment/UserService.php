<?php 

include 'DatabaseManager.php';
include 'Mcrypt.php';
include 'User.php';
include 'Post.php';

class UserService {

    private $databaseManager;
    private $mcrypt;
    private $connection;

    public function __construct() {
        $this->databaseManager = new DatabaseManager();
        $this->mcrypt = new Mcrypt();
        $this->connection = $this->databaseManager->getConnection(); 
    }
    
    /**
     * Check If Email and Password Matches for authentication purposes
     */
    public function checkUser($email, $password)
	{
        $userId = "";
        $stmt = $this->connection->prepare("SELECT * FROM USERS WHERE user_email = ? AND user_password = ?");
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $res = $stmt->get_result();
		if($res->num_rows > 0) {
			return $res->fetch_assoc()["user_id"];
		} else {
			return false;
        }
    }
    
    /**
     * Check if email exists
     */
    public function checkEmail($email) {
        $stmt = $this->connection->prepare("SELECT * FROM USERS WHERE user_email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();
        $stmt->close();
		if($res->num_rows > 0) {
			return false;
		} else {
			return true;
        }
    }

    /**
     * Save new user while registering
     */
    public function saveUser($fname, $email, $password, $address) {
        $stmt = $this->connection->prepare("INSERT INTO USERS (user_name, user_email, user_password, user_address) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fname, $email, $password, $address);
        $stmt->execute();
        $stmt->close();
    }

    /**
     * Save new post of the user
     */
    public function savePost($pname, $pmessage, $userId) {
        $stmt = $this->connection->prepare("INSERT INTO POSTS (post_name, post_message, user_id) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $pname, $pmessage, $userId);
        $stmt->execute();
        $stmt->close();
    }

    /**
     * Get All Users [NOT USED]
     */
    public function getAllUsers() {
        if($stmt = $this->connection->prepare("SELECT * FROM USERS")) {
            $stmt->execute();
            $result = $stmt->get_result();
            $users = array();
            while($row = $result->fetch_assoc()) {
                $user = new User();
                $user->setId($row['user_id']);
                $user->setName($row['user_name']);
                $user->setEmail($row['user_email']);
                $user->setAddress($row['user_address']);
                array_push($users, $user);
            }
            $stmt->close();
            return $users;
        }
    }

    /**
     * Get All Posts
     */
    public function getAllPosts() {
        if($stmt = $this->connection->prepare("SELECT * FROM POSTS")) {
            $stmt->execute();
            $result = $stmt->get_result();
            $posts = array();
            while($row = $result->fetch_assoc()) {
                $post = new Post();
                $post->setId($row['post_id']);
                $post->setName($row['post_name']);
                $post->setMessage($row['post_message']);
                array_push($posts, $post);
            }
            $stmt->close();
            return $posts;
        }
    }

}

?>