<?php
session_start();
include 'UserService.php';

$userService = new UserService();
$pname = $_POST['pname'];
$pmessage = $_POST['pmessage'];
if(validatePost($pname, $pmessage)) {
    $userService->savePost($pname, $pmessage, $_SESSION["userId"]);
    $_SESSION['serverMsg'] = "Your Post Uploaded Successfully!";
    header("Location:writepost_view.php");
} else {
    $_SESSION['serverMsg'] = "One Or More Fields Are Blank!";
    header("Location:writepost_view.php");
}

/**
 * Post Validation
 */
function validatePost($pname, $pmessage) {
    if($pname == "" || $pmessage == "") {
        return false;
    }
    return true;
}

?>